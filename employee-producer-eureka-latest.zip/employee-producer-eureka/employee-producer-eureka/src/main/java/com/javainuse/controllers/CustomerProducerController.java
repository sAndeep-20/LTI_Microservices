package com.javainuse.controllers;

import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.javainuse.model.Customer;
import com.javainuse.service.CustomerService;

@RestController
@RequestMapping("/customer")
public class CustomerProducerController {
	
	private CustomerService customerService;
	
	@PostMapping("/addCustomer")
	public Customer addCustomer(@RequestBody Customer customer) {
		//service call to add the data to database
		customerService.addCustomer(customer);
		return customer;
	}
	
	@PutMapping("/updateCustomer")
	public Customer updateCustomer(@RequestBody Customer customer) {
		//service call to update the data to database
		customerService.updateCustomer(customer);
		return customer;
	}
	
	@DeleteMapping("/deleteCustomer")
	public Customer deleteCustomer(@RequestBody Customer customer) {
		//service call to delete the data to database
		customerService.deleteCustomer(customer);
		return customer;
	}

}
