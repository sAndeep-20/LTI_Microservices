package com.javainuse.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.javainuse.model.Customer;
import com.javainuse.repository.customerRepository;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.ribbon.proxy.annotation.Hystrix;

@Service
public class CustomerService {
	@Autowired
	private customerRepository custRepo;
	
	@HystrixCommand(fallbackMethod = "addCustomerHandler")
	public Customer addCustomer(Customer customer) {
		return custRepo.save(customer);
	}
	
	public Customer addCustomerHandler() {
		return new Customer();
	}
	
	public Customer updateCustomer(Customer customer) {
		return custRepo.save(customer);
	}
	
	public void deleteCustomer(Customer customer) {
		custRepo.delete(customer);
	}
}
